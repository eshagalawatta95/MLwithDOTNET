﻿using Microsoft.ML.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLwithDOTNET
{
    public  class ModelInput
    {
        [ColumnName("age"), LoadColumn(0)]
        public float Age { get; set; }

        [ColumnName("sex"), LoadColumn(1)]
        public string Sex { get; set; }

        [ColumnName("bmi"), LoadColumn(2)]
        public float Bmi { get; set; }

        [ColumnName("children"), LoadColumn(3)]
        public float Children { get; set; }

        [ColumnName("smoker"), LoadColumn(4)]
        public bool Smoker { get; set; }

        [ColumnName("region"), LoadColumn(5)]
        public string Region { get; set; }

        [ColumnName("charges"), LoadColumn(6)]
        public float Charges { get; set; }
    }

    public class ModelOutput
    {
        public float Score { get; set; }
    }
}
